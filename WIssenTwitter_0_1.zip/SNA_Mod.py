'''
Created on Nov 24, 2012

@author: nicolas
'''
'''
Created on May 16, 2012

@author: nicolas
Carga Coleccion de Mongo en un graph de networkx
'''
import os,sys
import csv
import string
import json
import networkx as net
from decimal import *
from collections import Counter
import twitter_text


STOPWORDS="stopWords.csv"
DB = "gnip"
COL="gnip_politica"
LIMIT=100000
TRIAD_TARGET='300'

def entity_count_mapper(doc):
    if not doc.get('entities'):
        
        extractor = twitter_text.Extractor(doc['text'])

            # Note that the production Twitter API contains a few additional fields in
            # the entities hash that would require additional API calls to resolve

        entities = {}
        entities['user_mentions'] = []
        for um in extractor.extract_mentioned_screen_names_with_indices():
            entities['user_mentions'].append(um)

        entities['hashtags'] = []
        for ht in extractor.extract_hashtags_with_indices():

                # massage field name to match production twitter api

            ht['text'] = ht['hashtag']
            del ht['hashtag']
            entities['hashtags'].append(ht)

        entities['urls'] = []
        for url in extractor.extract_urls_with_indices():
            entities['urls'].append(url)

        doc['entities'] = entities

    # A mapper can, and often does, include multiple calls to "yield" which 
    # emits a key, value tuple. This tuple can be whatever you'd like. Here,
    # we emit a tweet entity as the key and the tweet id as the value, even
    # though it's really only the key that we're interested in analyzing.

        if doc['entities'].get('user_mentions'):
            for user_mention in doc['entities']['user_mentions']:
                yield ('@' + user_mention['screen_name'].lower(), doc['id'])

        if doc['entities'].get('hashtags'):
            for hashtag in doc['entities']['hashtags']:
                yield ('#' + hashtag['text'], doc['id'])

def create_graph(results_input):
    g=net.DiGraph()
    for result in results_input:
        if len(result["twitter_entities"]["user_mentions"])>0:
            for user in result["twitter_entities"]["user_mentions"]:
                try:
                    #cuando tengamos klout agregamos esto otra vez
#                    if "klout_score" in result["gnip"]:
#                        #print "adding %s" % result["actor"]["preferredUsername"]
#                        g.add_edge(result["actor"]["preferredUsername"],user["screen_name"],weight=result["gnip"]["klout_score"],regla=result["gnip"]["matching_rules"][0]["value"])
#                    else:
#                        # print "adding %s" % result["actor"]["preferredUsername"]
                    #g.add_weighted_edges_from(result["from_user"],user["screen_name"],1,texto=result["text"])
                    
                    g.add_edge(result["from_user"],user["screen_name"],texto=result["text"],idioma=result["iso_language_code"])
                except Exception,e:
                    print e
    return g

def freq_counter(results):
    cnt = Counter()
    total=0
    freq="["
    reader=csv.reader(open(os.path.join( os.path.dirname(sys.argv[0]), 'in',STOPWORDS)),delimiter=',', quotechar='"')
    stopList=[[row[0],1] for row in reader]
    stopDict=dict(stopList)
    for result in results:
        remove_punctuation_map = dict((ord(char), None) for char in string.punctuation) #quita puntuacion
        textIn= result["text"].translate(remove_punctuation_map)
        for word in textIn.split():
            if word in stopDict:
                pass
            else:
                total+=1
                cnt[word] += 1
    for element in cnt:
        if freq=="[":
            freq+='{"palabra":"'+element+'", "frecuencia": "'+str(Decimal(cnt[element])/Decimal(total))+'"}'
        else:
            freq+=',{"palabra":"'+element+'", "frecuencia": "'+str(Decimal(cnt[element])/Decimal(total))+'"}'
    freq+="]"
    return json.loads(freq),cnt
        
def save_to(input_file,file_name):
    print "saving to %s" %os.path.join( os.path.dirname(sys.argv[0]), 'out',file_name )
    if not os.path.isdir('out'):
        os.mkdir('out')
    f = open(os.path.join( os.path.dirname(sys.argv[0]), 'out',file_name ), 'w')
    f.write("Usuario,Numero de triadas de tipo %s\n" %TRIAD_TARGET)
    for user in input_file:
        f.write("%s,%s\n"%(user[1],user[0]))
    f.close()
    
def save_to_gml(graph,path):
    net.write_gml(graph,path)
    
def save_to_gexf(graph,path):
    net.write_gexf(graph, path)
    
#def calculate_triads(results,day_start):
#    print "creando red...\n"
#    tweet_graph=create_graph(results)
#    # seleccionar solo componentes conectados
#    print "calculando componentes...\n"
#    components=net.connected_component_subgraphs(tweet_graph)
#    # seleccionamos el componente mas grande
#    cc=components[0]
#    print components
#    print "calculando triadas....\n"
#    census,node_census=triadic.triadic_census(cc)
#    closed_triads=[[-k,v]for k,v in sorted ([[-node_census[k][TRIAD_TARGET],k]for k in node_census.keys()])]
#    return closed_triads
    