# -*- coding: utf-8 -*-
'''
Created on Nov 27, 2012

@author: nicolas
'''
import sys
import os
import json
#import pylab
import networkx as nx
import NetX
import pprint
import xlwt

from UI import display_menu

def loadJsons(paths):
#    i=0
    output=[]
    for path in paths:
        if os.path.isfile(path):
            raw_file=open(path).read()
#           try:
            output+=json.loads(raw_file)
#            i=i+1
#            print "length "+str(len(output))+ " at count "+str(i)
#            except:
    return output

#def output_graph(inputGraph):
#    d=nx.degree(inputGraph)
#    ds=NetX.sorted_map(d)
#    names1=[x[0] for x in ds[0:10]]
#    c=nx.closeness_centrality(inputGraph)
#    cs=NetX.sorted_map(c)
#    names2=[x[0] for x in cs[0:10]]
#    b=nx.betweenness_centrality(inputGraph)
#    bs=NetX.sorted_map(b)
#    names3=[x[0] for x in bs[0:10]]
#    e=nx.eigenvector_centrality(inputGraph,max_iter=1000)
#    es=NetX.sorted_map(e)
#    names4=[x[0] for x in es[0:10]]
#    names =list(set(names1)|set(names2)|set(names3)|set(names4))
#    table=["Name","Degree","closeness","betweenness","eigenvector"]
#    table.append([[name,d[name],c[name],b[name],e[name]]for name in names])
#    pp = pprint.PrettyPrinter()
#    print "\nTable "
#    pp.pprint(table)
#    print"\ntop gossipers"
#    pp.pprint(es[:10])
    
#    nx.draw(inputGraph)
 #   pylab.show()
    
#    print >> sys.stderr, "number nodes:", inputGraph.number_of_nodes()
#    print >> sys.stderr, "Node degrees:", sorted(nx.degree(inputGraph))
    
def createProject(files):
    pass

def create_folders(path):
    if not os.path.isdir(path+'/out'):
        os.mkdir(path+'/out')
    if not os.path.isdir(path+'/out/gexf'):
        os.mkdir(path+'/out/gexf')
    if not os.path.isdir(path+'/out/json'):
        os.mkdir(path+'/out/json')
    if not os.path.isdir(path+'/out/csv'):
        os.mkdir(path+'/out/csv')
    if not os.path.isdir(path+'/in'):
        os.mkdir(path+'/in')
    if not os.path.isdir(path+'/in/projects'):
        os.mkdir(path+'/in/projects')
        
def read_project(prt_file):
    pass

def unescape(s):
    s = s.replace("&lt;", "<")
    s = s.replace("&gt;", ">")
    # this has to be last:
    s = s.replace("&quot;",'"')
    s = s.replace("&amp;", "&")
    return s

def clean_source(s):
    s=unescape(s)
    s=s.replace('<a href="',"")
    s=s.replace('">',";")
    s=s.replace('</a>',"")
    return s
    
def combine_json(json_list):
    new_list = []
    for piece in json_list:
        json_piece=loadJsons([piece])
        for item in json_piece:
            if item not in new_list:
                new_list.append(item)

    return new_list
            
def json_csv_xlwt(input_json,type,proyecto,path):
    if type=="user": #prepara el json de usuarios para convertitlo en xls
        wbk = xlwt.Workbook()
        sheet = wbk.add_sheet('sheet 1')
        filename=proyecto + '_user.xls'
        csv_file = path+"/" + filename
        while os.path.isfile(csv_file):
            print "ya existe "+ filename
            rewrite_menu={1:"sobre escribir",2:"cambiar nombre"}
            id=display_menu(rewrite_menu)
            if rewrite_menu[id]=="cambiar nombre":
                filename=raw_input('\nQue nombre le quieres poner al archivo '+ filename + ': ')
                if '.xls' in filename:
                    csv_file=(path+"/" +filename)
                else:
                    csv_file=(path+"/" +filename+'.xls')
            else:
                break
        index_r=0
        index_c=0
        for element in ["screen_name","name","status","idioma","followers","friends","lugar"]:
            sheet.write(index_r,index_c,element)
            index_c+=1
        index_c=0
        index_r+=1
       
        for ele_ind in input_json:
            element=input_json[ele_ind]
            try:
                for lst_element in [element["screen_name"],element["name"],element["status"]["text"],element["lang"],str(element["followers_count"]),str(element["friends_count"])]:
                    sheet.write(index_r,index_c,lst_element)
                    index_c+=1
                index_c=0
                index_r+=1
            except KeyError as e:
                if e.message == "status":
                    for lst_element in [element["screen_name"],element["name"],"None",element["lang"],str(element["followers_count"]),str(element["friends_count"]),element["location"]]:
                        sheet.write(index_r,index_c,lst_element)
                        index_c+=1
                index_c=0
                index_r+=1
            except UnicodeEncodeError as e:
                print e
        wbk.save(csv_file)
                
    elif type=="tweet": #prepara el json de tweets para convertitlo en xls
        wbk = xlwt.Workbook()
        sheet = wbk.add_sheet('sheet 1')
        filename=proyecto + '_tweet.xls'
        csv_file = path+"/" + filename
        while os.path.isfile(csv_file):
            print "ya existe "+ filename
            rewrite_menu={1:"sobre escribir",2:"cambiar nombre"}
            id=display_menu(rewrite_menu)
            if rewrite_menu[id]=="cambiar nombre":
                filename=raw_input('\nQue nombre le quieres poner al archivo '+ filename+ ': ')
                if '.xls' in filename:
                    csv_file=(path+"/" +filename)
                else:
                    csv_file=(path+"/" +filename+'.xls')
            else:
                break
        index_r=0
        index_c=0
        for element in ["From","From Name","To","To Name","User Mentions","Idioma","Lugar","Source","Hashtags","Urls","Text", "Creao"]:
            sheet.write(index_r,index_c,element)
            index_c+=1
        index_c=0
        index_r+=1
        for element in input_json:
            try:
                hashtags=""
                urls=""
                mentions=""
                from_user=element["from_user"]
                if "K tal la" in from_user:
                    print "here"
                from_name=element["from_user_name"]
                lang=element["iso_language_code"]
                if element["to_user"] is None:
                    to_user=""
                    to_user_name=""
                else:
                    to_user= element["to_user"]
                    to_user_name= element["to_user_name"]
                if element["geo"] is None:
                    try:
                        location=element["location"]
                    except KeyError as e:
                        location=""
                else:
                    try:
                        if element["location"] !="":
                            location=element["location"]+", ("+element["geo"]["coordinates"][0]+","+element["geo"]["coordinates"][1]+")"
                        else:
                            location="("+element["geo"]["coordinates"][0]+","+element["geo"]["coordinates"][1]+")"
                    except KeyError as e:
                        if "location" in e.message:
                            location="("+str(element["geo"]["coordinates"][0])+","+str(element["geo"]["coordinates"][1])+")"
                source=clean_source(element["source"])
                for hashtag in element['twitter_entities']["hashtags"]:
                    if hashtags=="":
                        hashtags=hashtag["text"]
                    else:
                        hashtags=hashtags+","+hashtag["text"]
                for url in element['twitter_entities']["urls"]:
                    if urls=="":
                        urls=url["url"]
                    else:
                        urls+=urls+","+url["url"]
                for mention in element['twitter_entities']["user_mentions"]:
                    if mentions=="":
                        mentions=mention["screen_name"]
                    else:
                        mentions=mentions+","+mention["screen_name"]
                try:
                    texto =element["text"]
                except UnicodeEncodeError as e:
                    print e
                creado=element["created_at"]
                #Acaba de recuperar informacion para meter al csv
                for element in [from_user,from_name,to_user,to_user_name,mentions,lang,location,source,hashtags,urls,texto,creado]:
                    char_count=0
                    for char in element:
                        char_count+=1
                    if char_count>=32767:
                        print element+" esta muy largo"
                    sheet.write(index_r,index_c,element)
                    index_c+=1
                index_c=0
                index_r+=1
            except TypeError as e:
                if "dict" in e.message:
                    for ele_ind2 in ele_ind:
                        print ele_ind2   
        wbk.save(csv_file)             
    elif type=="freq_count": #prepara la lista de frequencias de palabras para pasar a xls
        wbk = xlwt.Workbook()
        sheet = wbk.add_sheet('sheet 1')
        filename=proyecto + '_word_freq.xls'
        csv_file = path+"/" + filename
        while os.path.isfile(csv_file):
            print "ya existe "+ filename
            rewrite_menu={1:"sobre escribir",2:"cambiar nombre"}
            id=display_menu(rewrite_menu)
            if rewrite_menu[id]=="cambiar nombre":
                filename=raw_input('\nQue nombre le quieres poner al archivo '+ filename + ': ')
                if '.xls' in filename:
                    csv_file=(path+"/" +filename)
                else:
                    csv_file=(path+"/" +filename+'.xls')
            else:
                break
        index_r=1
        sheet.write(0,0,"Palabra")
        sheet.write(0,1,"Frecuencia")
        for element in input_json:
            sheet.write(index_r,0,element["palabra"])
            sheet.write(index_r,1,element["frecuencia"])
            index_r+=1
        wbk.save(csv_file)
        