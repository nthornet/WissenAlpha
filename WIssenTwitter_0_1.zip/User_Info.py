# -*- coding: utf-8 -*-
'''
Created on Dec 3, 2012

@author: nicolas
'''

from TwitterRequester import make_twitter_request

def get_info_by_id(t, ids):

    id_to_info = {}

    while len(ids) > 0:

        # Process 100 ids at a time...

        ids_str = ','.join([str(_id) for _id in ids[:100]])
        ids = ids[100:]

#        print ids_str
        response = make_twitter_request(t, 
                                      getattr(getattr(t, "users"), "lookup"),
                                      user_id=ids_str)
     
        if response is None:
            break

        if type(response) is dict:  # Handle Twitter API quirk
            response = [response]

        for user_info in response:
            id_to_info[user_info['id']] = user_info

        return id_to_info
    
def get_info_by_screen_name(t, screen_names):

    sn_to_info = {}

    while len(screen_names) > 0:

        # Process 100 ids at a time...

        screen_names_str = ','.join([str(sn) for sn in screen_names[:100]])
        screen_names = screen_names[100:]

        response = make_twitter_request(t, 
                                      getattr(getattr(t, "users"), "lookup"),
                                      screen_name=screen_names_str)
     
        if response is None:
            break

        if type(response) is dict:  # Handle Twitter API quirk
            response = [response]

        for user_info in response:
            sn_to_info[user_info['screen_name']] = user_info

        return sn_to_info