# -*- coding: utf-8 -*-
'''
Created on Nov 27, 2012

@author: nicolas
'''
import os,sys
import csv
import string
import json
import networkx as net
from decimal import *
from collections import Counter
import twitter_text
import twitter
import json
import datetime
import Dock
import NetX
import TwitterRequester
import User_Info
from OAuth                      import oauth_login
from TwitterSearch              import get_search
from extract_tweet_entities     import get_entities
#from Geocoder                   import processTweet 
#from Geocoder                   import processTweetText
from SNA_Mod                    import create_graph
from SNA_Mod                    import save_to_gexf
from SNA_Mod                    import freq_counter
#from SQL_Tools                  import insert_Gephi
from User_Info                  import get_info_by_id

path=os.path.join(os.path.dirname(sys.argv[0]), 'out')
gexf_path=os.path.join(os.path.dirname(sys.argv[0]), 'out/gexf')
json_path=os.path.join(os.path.dirname(sys.argv[0]), 'out/json')
csv_path=os.path.join(os.path.dirname(sys.argv[0]), 'out/csv')
TOP=10
APP_NAME = 'ThorneHarvester' 
CONSUMER_KEY = '68R3Ko3fjLyycenGbi3scQ' 
CONSUMER_SECRET = 'UlHLW4IT2ynvETI5vPy9rK8Kdu22Eyjp9Ekw5kFbZg'

def action1():
    pass # put a function here

def action2():
    pass # blah blah

def action3():
    pass # and so on

def no_such_action():
    pass # print a message indicating there's no such action

def display_menu(menu,output=1):
    for option in menu:
        print '[%i] %s' % (option, menu[option]) 
        # Prompt the user
    if output==1:
        idx = int(raw_input('\nEscoge una Funcion: '))
    elif output==2:
        idx = raw_input('\nEscoge una Funcion: ')
    return idx

if __name__ == '__main__':
    proyecto=""
    geo=""
    Dock.create_folders(os.path.dirname(sys.argv[0]))
    ids=[]
    t=oauth_login(APP_NAME, CONSUMER_KEY, CONSUMER_SECRET)
    main_menu={1:"Buscar",2:"Cargar Red Desde Json"}
    user_input=display_menu(main_menu)
    if main_menu[user_input]=="Buscar":
        now = datetime.datetime.now()
        strNow=now.strftime("%Y-%m-%d %H:%M")
        MAX_PAGES = 15
        RESULTS_PER_PAGE = 100
        query=raw_input('\nQue Busqueda te Gustaria hacer?: ')
        geo=raw_input('\nSi te gustaria agregar un codigo de geolocalizacion agreguelo aqui si no dejelo en blanco. \n'+
                      'La golocalizacion es de la siguiente manera latitude,longitude,radio \n'+
                      'por ejempo para mexico df con un radio de una milla seria 19.4341667,-99.1386111,1mi : ') 
        proyecto=raw_input("\nComo se llama tu proyecto?")
        #geo="19.4341667,-99.1386111,1mi" #Geolocalizacion
        t = twitter.Twitter(domain="search.twitter.com")
        search_results=get_search(t,query,geo,RESULTS_PER_PAGE,MAX_PAGES)
        if geo!="":
            f = open(os.path.join(os.path.dirname(sys.argv[0]), 'out/json', 'search_results_'+query+'_'+geo+'_'+strNow+'.json'), 'w')
            f.write(json.dumps(search_results, indent=1))
            f.close()
        else:
            f = open(os.path.join(os.path.dirname(sys.argv[0]), 'out/json', 'search_results_'+query+'_'+strNow+'.json'), 'w')
            f.write(json.dumps(search_results, indent=1))
            f.close()
        loaded_data=search_results
    elif main_menu[user_input]=="Cargar Red Desde Json":
        files={}
        id=0
        for dirname, dirnames, filenames in os.walk(path+'/json'):
            for subdirname in dirnames:
                print os.path.join(dirname, subdirname)
            for filename in filenames:
                if filename != ".DS_Store" and "users_" not in filename:
                    id+=1
                    files[id]=os.path.join(dirname, filename)
        proyecto=raw_input("\nComo se llama tu proyecto?")
        print "escoger todos los archivos que quiera cargar separados por coma"
        user_input=display_menu(files,output=2)
        print user_input
        input_split=user_input.split(",")
        paths=[]
        for input in input_split:
            paths.append(files[int(input)])
        loaded_data=Dock.combine_json(paths)
#        loaded_data=Dock.loadJsons(paths)
        
    #crear archivos
    count_json,count=freq_counter(loaded_data)
    for result in loaded_data:
        ids.append(result["from_user_id"])
        result['twitter_entities'] = get_entities(result)
    try:
        users=get_info_by_id(t,ids)
        users_json=json.dumps(users,indent=1)
        Dock.json_csv_xlwt(users,"user",proyecto,csv_path)
    except twitter.api.TwitterHTTPError as e:
        print "solo se puede conseguir informacion de usuarios si se carga un json"
    graph=create_graph(loaded_data) 
    Dock.json_csv_xlwt(loaded_data,"tweet",proyecto,csv_path)
    Dock.json_csv_xlwt(count_json,"freq_count",proyecto,csv_path)
    if geo != "":
        gexf_filename='search_results_'+proyecto+'_'+geo+'.gexf'
        save_to_gexf(graph,gexf_path+'/'+gexf_filename)
    else:
        gexf_filename='search_results_'+proyecto+'.gexf'
        save_to_gexf(graph,gexf_path+'/'+gexf_filename)   

print "done"